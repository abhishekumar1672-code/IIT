package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val StudyTubeDarkColorScheme = darkColorScheme(
    primary = StudySkyBlue,
    onPrimary = StudyObsidian,
    primaryContainer = StudySkyBlueContainer,
    onPrimaryContainer = StudyTextPrimary,
    secondary = StudyEmerald,
    onSecondary = StudyObsidian,
    secondaryContainer = StudyEmeraldContainer,
    onSecondaryContainer = StudyTextPrimary,
    tertiary = StudyAmber,
    background = StudyObsidian,
    onBackground = StudyTextPrimary,
    surface = StudySurface,
    onSurface = StudyTextPrimary,
    surfaceVariant = StudySurfaceVariant,
    onSurfaceVariant = StudyTextSecondary,
    outline = StudyBorder,
    error = StudyCrimson,
    onError = StudyTextPrimary,
    errorContainer = StudyCrimsonContainer,
    onErrorContainer = StudyTextPrimary
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = StudyTubeDarkColorScheme,
        typography = Typography,
        content = content
    )
}
