package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val StudyObsidian = Color(0xFF0B0F17)
val StudySurface = Color(0xFF131B2E)
val StudySurfaceVariant = Color(0xFF1E293B)
val StudyBorder = Color(0xFF26354D)
val StudySkyBlue = Color(0xFF38BDF8)
val StudySkyBlueContainer = Color(0xFF0C2D48)
val StudyEmerald = Color(0xFF10B981)
val StudyEmeraldContainer = Color(0xFF064E3B)
val StudyCrimson = Color(0xFFF43F5E)
val StudyCrimsonContainer = Color(0xFF4C0519)
val StudyAmber = Color(0xFFF59E0B)
val StudyTextPrimary = Color(0xFFF8FAFC)
val StudyTextSecondary = Color(0xFF94A3B8)
val StudyTextMuted = Color(0xFF64748B)
