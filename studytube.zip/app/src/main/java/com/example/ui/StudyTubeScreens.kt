package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.StudyVideo
import com.example.data.WHITELISTED_CHANNELS
import com.example.ui.theme.StudyBorder
import com.example.ui.theme.StudyEmerald
import com.example.ui.theme.StudyObsidian
import com.example.ui.theme.StudySkyBlue
import com.example.ui.theme.StudySurface
import com.example.ui.theme.StudyTextMuted
import com.example.ui.theme.StudyTextPrimary
import com.example.ui.theme.StudyTextSecondary

@Composable
fun StudyTubeApp(
    viewModel: StudyTubeViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val lifecycleOwner = LocalLifecycleOwner.current

    // Auto-refresh when app comes to the foreground
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.onAppForegrounded()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = StudyObsidian,
        topBar = {
            Column(modifier = Modifier.fillMaxWidth()) {
                StudyTubeTopBar(
                    searchQuery = uiState.searchQuery,
                    onSearchQueryChange = viewModel::updateSearchQuery,
                    studiedSecondsToday = uiState.studiedSecondsToday,
                    isTimerRunning = uiState.isStudyTimerRunning,
                    onToggleTimer = viewModel::toggleStudyTimer,
                    isSyncing = uiState.isSyncing,
                    onRefreshClick = { viewModel.refreshFeed(force = true) },
                    onSettingsClick = { viewModel.setShowSettingsDialog(true) },
                    onHtmlDialogClick = { viewModel.setShowSingleFileHtmlSheet(true) },
                    onBrandClick = {
                        viewModel.closeWatchPage()
                        viewModel.toggleSingleFileWebViewMode(false)
                    }
                )
                if (!uiState.isSingleFileWebViewMode) {
                    WhitelistFilterChipsRow(
                        activeChip = uiState.activeChip,
                        onSelectChip = viewModel::selectChip
                    )
                }
                HorizontalDivider(color = StudyBorder)
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when {
                uiState.isSingleFileWebViewMode -> {
                    BackHandler {
                        viewModel.toggleSingleFileWebViewMode(false)
                    }
                    SingleFileStudyTubeWebView(
                        apiKey = uiState.apiKey,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                uiState.selectedVideo != null -> {
                    BackHandler {
                        viewModel.closeWatchPage()
                    }
                    StudyWatchScreen(
                        video = uiState.selectedVideo!!,
                        relatedVideos = uiState.relatedVideos,
                        onBackToFeed = viewModel::closeWatchPage,
                        onSelectRelatedVideo = viewModel::openVideoWatchPage,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                else -> {
                    StudyFeedGridScreen(
                        uiState = uiState,
                        onVideoClick = viewModel::openVideoWatchPage,
                        onOpenSettings = { viewModel.setShowSettingsDialog(true) },
                        onRetrySync = { viewModel.refreshFeed(force = true) },
                        onResetFilters = {
                            viewModel.selectChip("All")
                            viewModel.updateSearchQuery("")
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }

    if (uiState.showSettingsDialog) {
        ApiKeySettingsDialog(
            currentApiKey = uiState.apiKey,
            cachedChannels = uiState.cachedChannels,
            onDismiss = { viewModel.setShowSettingsDialog(false) },
            onSaveApiKey = viewModel::saveApiKeyAndSync,
            onClearCache = viewModel::clearCache
        )
    }

    if (uiState.showSingleFileHtmlSheet) {
        SingleFileHtmlExportDialog(
            htmlCode = uiState.singleFileHtmlCode,
            isWebViewModeActive = uiState.isSingleFileWebViewMode,
            onToggleWebViewMode = viewModel::toggleSingleFileWebViewMode,
            onDismiss = { viewModel.setShowSingleFileHtmlSheet(false) }
        )
    }
}

@Composable
private fun StudyFeedGridScreen(
    uiState: StudyTubeUiState,
    onVideoClick: (StudyVideo) -> Unit,
    onOpenSettings: () -> Unit,
    onRetrySync: () -> Unit,
    onResetFilters: () -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val columns = when {
            maxWidth >= 900.dp -> 3
            maxWidth >= 560.dp -> 2
            else -> 1
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(columns),
            contentPadding = PaddingValues(14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier
                .fillMaxSize()
                .testTag("video_feed_grid")
        ) {
            // Compact Focus Hero Strip
            item(span = { GridItemSpan(maxLineSpan) }) {
                StudyFocusStatusStrip(
                    lectureCount = uiState.filteredVideos.size,
                    lastSyncEpochMs = uiState.lastSyncEpochMs,
                    isSyncing = uiState.isSyncing
                )
            }

            // Friendly API error / invalid key / quota exceeded banner
            if (uiState.apiError != null) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    ApiErrorBanner(
                        errorState = uiState.apiError,
                        onOpenSettings = onOpenSettings,
                        onRetry = onRetrySync
                    )
                }
            }

            // Empty state when no videos match or no key configured yet
            if (uiState.filteredVideos.isEmpty() && !uiState.isSyncing) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    EmptyFeedHeroBanner(
                        hasApiKey = uiState.apiKey.isNotBlank(),
                        onConfigureApiKey = onOpenSettings,
                        onResetFilters = onResetFilters
                    )
                }
            }

            // Whitelisted Videos Grid
            items(
                items = uiState.filteredVideos,
                key = { it.id }
            ) { video ->
                StudyVideoCard(
                    video = video,
                    onClick = { onVideoClick(video) }
                )
            }
        }
    }
}

@Composable
private fun StudyFocusStatusStrip(
    lectureCount: Int,
    lastSyncEpochMs: Long,
    isSyncing: Boolean
) {
    val syncLabel = when {
        isSyncing -> "Syncing whitelisted uploads…"
        lastSyncEpochMs == 0L -> "Not synced yet"
        else -> {
            val mins = ((System.currentTimeMillis() - lastSyncEpochMs) / 60_000L).coerceAtLeast(0L)
            if (mins == 0L) "Updated just now" else "Updated ${mins}m ago"
        }
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = StudySurface),
        border = BorderStroke(1.dp, StudyBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Image(
                painter = painterResource(id = R.drawable.img_study_banner_1794405851434),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alpha = 0.22f,
                modifier = Modifier
                    .matchParentSize()
                    .clip(RoundedCornerShape(12.dp))
            )
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                StudyObsidian.copy(alpha = 0.92f),
                                StudySurface.copy(alpha = 0.78f)
                            )
                        )
                    )
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = StudySkyBlue,
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        text = "Shorts & Live Blocked (>60s) • $syncLabel",
                        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                        color = StudyTextSecondary
                    )
                }

                Text(
                    text = "$lectureCount Lectures • ${WHITELISTED_CHANNELS.size} Channels",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudySkyBlue,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun StudyWatchScreen(
    video: StudyVideo,
    relatedVideos: List<StudyVideo>,
    onBackToFeed: () -> Unit,
    onSelectRelatedVideo: (StudyVideo) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = modifier
            .fillMaxSize()
            .testTag("watch_page_screen")
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onBackToFeed,
                    border = BorderStroke(1.dp, StudyBorder),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("back_to_feed_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to Feed",
                        tint = StudyTextPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Back to Feed", color = StudyTextPrimary)
                }

                Surface(
                    color = StudyEmerald.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(999.dp),
                    border = BorderStroke(1.dp, StudyEmerald.copy(alpha = 0.35f))
                ) {
                    Text(
                        text = "● Official Embedded Player",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF34D399),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
        }

        // Official YouTube Embedded IFrame Player
        item {
            OfficialYouTubeIframePlayer(videoId = video.id)
        }

        // Video Details Card (No comments, no external distractions)
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = StudySurface),
                border = BorderStroke(1.dp, StudyBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = video.title,
                        style = MaterialTheme.typography.titleLarge,
                        color = StudyTextPrimary
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = video.fullChannelName,
                            style = MaterialTheme.typography.titleSmall,
                            color = StudySkyBlue
                        )
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Whitelisted Channel",
                            tint = StudySkyBlue,
                            modifier = Modifier.size(15.dp)
                        )
                    }

                    Text(
                        text = "${video.viewsFormatted} • ${video.relativeTimeText} • Duration ${video.durationFormatted}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = StudyTextSecondary
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        video.tags.forEach { tag ->
                            Surface(
                                color = StudySkyBlue.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(999.dp)
                            ) {
                                Text(
                                    text = tag,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StudySkyBlue,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Related Videos Header (Strictly from whitelisted channels)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Related Whitelisted Lectures",
                    style = MaterialTheme.typography.titleMedium,
                    color = StudyTextPrimary
                )
                Text(
                    text = "Whitelist Only",
                    style = MaterialTheme.typography.labelSmall,
                    color = StudyTextMuted
                )
            }
        }

        items(
            items = relatedVideos,
            key = { "related_${it.id}" }
        ) { relatedVideo ->
            StudyVideoCard(
                video = relatedVideo,
                onClick = { onSelectRelatedVideo(relatedVideo) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
