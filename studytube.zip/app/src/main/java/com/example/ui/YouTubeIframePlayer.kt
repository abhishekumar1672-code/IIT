package com.example.ui

import android.annotation.SuppressLint
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

private fun isVirtualizedEmulator(): Boolean {
    val fingerprint = Build.FINGERPRINT.lowercase()
    val model = Build.MODEL.lowercase()
    val product = Build.PRODUCT.lowercase()
    return fingerprint.contains("generic") ||
        fingerprint.contains("emulator") ||
        model.contains("sdk_gphone") ||
        model.contains("emulator") ||
        product.contains("sdk") ||
        product.contains("emulator")
}

/**
 * Plays YouTube videos strictly using the official YouTube embedded iframe player.
 * Never downloads or copies video streams.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun OfficialYouTubeIframePlayer(
    videoId: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val safeVideoId = remember(videoId) {
        videoId.replace(Regex("[^a-zA-Z0-9_-]"), "")
    }

    val embedHtml = remember(safeVideoId) {
        """
        <!DOCTYPE html>
        <html>
        <head>
          <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
          <style>
            html, body {
              margin: 0;
              padding: 0;
              width: 100%;
              height: 100%;
              background-color: #000000;
              overflow: hidden;
            }
            iframe {
              position: absolute;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
              border: 0;
            }
          </style>
        </head>
        <body>
          <iframe
            src="https://www.youtube.com/embed/$safeVideoId?autoplay=1&rel=0&modestbranding=1&playsinline=1"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowfullscreen>
          </iframe>
        </body>
        </html>
        """.trimIndent()
    }

    val webView = remember {
        WebView(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            if (isVirtualizedEmulator()) {
                setLayerType(View.LAYER_TYPE_SOFTWARE, null)
            }
            setBackgroundColor(android.graphics.Color.BLACK)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                loadWithOverviewMode = true
                useWideViewPort = true
                cacheMode = WebSettings.LOAD_DEFAULT
            }
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onRenderProcessGone(
                    view: WebView?,
                    detail: RenderProcessGoneDetail?
                ): Boolean {
                    view?.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
                    return true
                }
            }
        }
    }

    DisposableEffect(safeVideoId) {
        webView.loadDataWithBaseURL(
            "https://www.youtube.com",
            embedHtml,
            "text/html",
            "UTF-8",
            null
        )
        onDispose {
            webView.stopLoading()
            webView.loadUrl("about:blank")
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .clip(RoundedCornerShape(14.dp))
            .background(Color.Black)
            .testTag("youtube_iframe_player")
    ) {
        AndroidView(
            factory = { webView },
            modifier = Modifier.fillMaxSize()
        )
    }
}

/**
 * Hosts the complete single-file mobile-first StudyTube web app (file:///android_asset/index.html)
 * directly inside an Android WebView when the user switches to Single-File Web mode.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun SingleFileStudyTubeWebView(
    apiKey: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val webView = remember {
        WebView(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            if (isVirtualizedEmulator()) {
                setLayerType(View.LAYER_TYPE_SOFTWARE, null)
            }
            setBackgroundColor(android.graphics.Color.parseColor("#0B0F17"))
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                allowFileAccess = true
                cacheMode = WebSettings.LOAD_DEFAULT
            }
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (apiKey.isNotBlank()) {
                        val escaped = apiKey.replace("'", "\\'")
                        view?.evaluateJavascript(
                            """
                            (function() {
                              if (!localStorage.getItem('studytube_yt_api_key_v1')) {
                                localStorage.setItem('studytube_yt_api_key_v1', '$escaped');
                                location.reload();
                              }
                            })();
                            """.trimIndent(),
                            null
                        )
                    }
                }

                override fun onRenderProcessGone(
                    view: WebView?,
                    detail: RenderProcessGoneDetail?
                ): Boolean {
                    view?.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
                    return true
                }
            }
            loadUrl("file:///android_asset/index.html")
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            webView.stopLoading()
            webView.destroy()
        }
    }

    AndroidView(
        factory = { webView },
        modifier = modifier
            .fillMaxSize()
            .testTag("single_file_webview")
    )
}
