package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ApiErrorState
import com.example.data.ApiException
import com.example.data.CachedChannelIdentity
import com.example.data.StudyTubeRepository
import com.example.data.StudyVideo
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

data class StudyTubeUiState(
    val apiKey: String = "",
    val allVideos: List<StudyVideo> = emptyList(),
    val filteredVideos: List<StudyVideo> = emptyList(),
    val activeChip: String = "All",
    val searchQuery: String = "",
    val selectedVideo: StudyVideo? = null,
    val relatedVideos: List<StudyVideo> = emptyList(),
    val isSyncing: Boolean = false,
    val lastSyncEpochMs: Long = 0L,
    val apiError: ApiErrorState? = null,
    val showSettingsDialog: Boolean = false,
    val showSingleFileHtmlSheet: Boolean = false,
    val isSingleFileWebViewMode: Boolean = false,
    val cachedChannels: Map<String, CachedChannelIdentity> = emptyMap(),
    val studiedSecondsToday: Int = 0,
    val isStudyTimerRunning: Boolean = true,
    val singleFileHtmlCode: String = ""
)

class StudyTubeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = StudyTubeRepository(application)

    private val _uiState = MutableStateFlow(StudyTubeUiState())
    val uiState: StateFlow<StudyTubeUiState> = _uiState.asStateFlow()

    private var timerJob: Job? = null
    private var autoRefreshJob: Job? = null

    init {
        val initialKey = repository.getEffectiveApiKey()
        val cachedVideos = repository.getCachedVideos()
        val cachedChannels = repository.getCachedChannelMap()
        val lastSync = repository.getLastSyncEpochMs()
        val studiedSeconds = repository.getStudiedSecondsToday()
        val htmlSource = repository.readSingleFileHtmlAsset()

        _uiState.update { state ->
            state.copy(
                apiKey = initialKey,
                allVideos = cachedVideos,
                filteredVideos = filterVideoList(cachedVideos, "All", ""),
                cachedChannels = cachedChannels,
                lastSyncEpochMs = lastSync,
                studiedSecondsToday = studiedSeconds,
                showSettingsDialog = initialKey.isBlank(),
                singleFileHtmlCode = htmlSource
            )
        }

        startStudyFocusTicker()
        startFiveMinuteAutoRefreshTicker()

        if (initialKey.isNotBlank()) {
            val isStale = System.currentTimeMillis() - lastSync >= FIVE_MINUTES_MS
            if (cachedVideos.isEmpty() || isStale) {
                refreshFeed(force = false)
            }
        }
    }

    private fun startStudyFocusTicker() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (isActive) {
                delay(1_000L)
                if (_uiState.value.isStudyTimerRunning) {
                    val updatedSeconds = repository.incrementAndSaveStudySeconds(1)
                    _uiState.update { it.copy(studiedSecondsToday = updatedSeconds) }
                }
            }
        }
    }

    private fun startFiveMinuteAutoRefreshTicker() {
        autoRefreshJob?.cancel()
        autoRefreshJob = viewModelScope.launch {
            while (isActive) {
                delay(FIVE_MINUTES_MS)
                if (_uiState.value.apiKey.isNotBlank() && !_uiState.value.isSyncing) {
                    refreshFeed(force = false)
                }
            }
        }
    }

    fun onAppForegrounded() {
        val state = _uiState.value
        val updatedTodaySeconds = repository.getStudiedSecondsToday()
        _uiState.update { it.copy(studiedSecondsToday = updatedTodaySeconds) }

        if (state.apiKey.isNotBlank() && !state.isSyncing) {
            val elapsed = System.currentTimeMillis() - state.lastSyncEpochMs
            if (state.allVideos.isEmpty() || elapsed >= FIVE_MINUTES_MS) {
                refreshFeed(force = false)
            }
        }
    }

    fun toggleStudyTimer() {
        _uiState.update { it.copy(isStudyTimerRunning = !it.isStudyTimerRunning) }
    }

    fun refreshFeed(force: Boolean = true) {
        val currentKey = repository.getEffectiveApiKey()
        if (currentKey.isBlank()) {
            _uiState.update { it.copy(showSettingsDialog = true) }
            return
        }
        if (_uiState.value.isSyncing) return

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isSyncing = true,
                    apiError = if (force) null else it.apiError
                )
            }

            val result = repository.syncWhitelistedFeed()
            result.fold(
                onSuccess = { freshVideos ->
                    val currentChip = _uiState.value.activeChip
                    val currentQuery = _uiState.value.searchQuery
                    val filtered = filterVideoList(freshVideos, currentChip, currentQuery)
                    val currentSelected = _uiState.value.selectedVideo
                    val related = if (currentSelected != null) {
                        computeRelatedLectures(currentSelected, freshVideos)
                    } else {
                        emptyList()
                    }
                    _uiState.update {
                        it.copy(
                            allVideos = freshVideos,
                            filteredVideos = filtered,
                            relatedVideos = related,
                            cachedChannels = repository.getCachedChannelMap(),
                            lastSyncEpochMs = repository.getLastSyncEpochMs(),
                            isSyncing = false,
                            apiError = null
                        )
                    }
                },
                onFailure = { throwable ->
                    val errState = (throwable as? ApiException)?.errorState
                    _uiState.update {
                        it.copy(
                            isSyncing = false,
                            apiError = errState,
                            cachedChannels = repository.getCachedChannelMap()
                        )
                    }
                }
            )
        }
    }

    fun saveApiKeyAndSync(newKey: String) {
        val trimmed = newKey.trim()
        repository.saveApiKey(trimmed)
        _uiState.update {
            it.copy(
                apiKey = trimmed,
                showSettingsDialog = false,
                apiError = null
            )
        }
        if (trimmed.isNotBlank()) {
            refreshFeed(force = true)
        }
    }

    fun clearCache() {
        repository.clearFeedAndChannelCache()
        _uiState.update {
            it.copy(
                allVideos = emptyList(),
                filteredVideos = emptyList(),
                relatedVideos = emptyList(),
                cachedChannels = emptyMap(),
                lastSyncEpochMs = 0L,
                apiError = null
            )
        }
    }

    fun selectChip(chip: String) {
        _uiState.update { state ->
            val filtered = filterVideoList(state.allVideos, chip, state.searchQuery)
            state.copy(
                activeChip = chip,
                filteredVideos = filtered,
                selectedVideo = null,
                relatedVideos = emptyList()
            )
        }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { state ->
            val filtered = filterVideoList(state.allVideos, state.activeChip, query)
            state.copy(
                searchQuery = query,
                filteredVideos = filtered,
                selectedVideo = null,
                relatedVideos = emptyList()
            )
        }
    }

    fun openVideoWatchPage(video: StudyVideo) {
        _uiState.update { state ->
            state.copy(
                selectedVideo = video,
                relatedVideos = computeRelatedLectures(video, state.allVideos),
                isStudyTimerRunning = true
            )
        }
    }

    fun closeWatchPage() {
        _uiState.update {
            it.copy(
                selectedVideo = null,
                relatedVideos = emptyList()
            )
        }
    }

    fun setShowSettingsDialog(show: Boolean) {
        _uiState.update { it.copy(showSettingsDialog = show) }
    }

    fun setShowSingleFileHtmlSheet(show: Boolean) {
        _uiState.update { it.copy(showSingleFileHtmlSheet = show) }
    }

    fun toggleSingleFileWebViewMode(enabled: Boolean) {
        _uiState.update { it.copy(isSingleFileWebViewMode = enabled) }
    }

    private fun filterVideoList(
        videos: List<StudyVideo>,
        activeChip: String,
        query: String
    ): List<StudyVideo> {
        val cleanQuery = query.trim().lowercase(Locale.US)
        return videos.filter { video ->
            // Enforce anti-Shorts invariant everywhere
            if (!StudyTubeRepository.isStrictValidLecture(video.durationSeconds, video.title)) {
                return@filter false
            }

            val matchesChip = when {
                activeChip == "All" -> true
                activeChip.startsWith("channel:") -> {
                    val key = activeChip.removePrefix("channel:")
                    video.channelKey == key
                }
                else -> video.tags.any { it.equals(activeChip, ignoreCase = true) }
            }
            if (!matchesChip) return@filter false

            if (cleanQuery.isNotEmpty()) {
                val searchable = "${video.title} ${video.channelTitle} ${video.fullChannelName} ${video.tags.joinToString(" ")}"
                    .lowercase(Locale.US)
                if (!searchable.contains(cleanQuery)) return@filter false
            }

            true
        }
    }

    private fun computeRelatedLectures(
        current: StudyVideo,
        pool: List<StudyVideo>
    ): List<StudyVideo> {
        return pool
            .asSequence()
            .filter { it.id != current.id && StudyTubeRepository.isStrictValidLecture(it.durationSeconds, it.title) }
            .sortedWith(
                compareByDescending<StudyVideo> { candidate ->
                    val sameChannelBonus = if (candidate.channelKey == current.channelKey) 2 else 0
                    val sharedTags = candidate.tags.count { it in current.tags }
                    sameChannelBonus + sharedTags
                }.thenByDescending { it.publishedEpochMs }
            )
            .take(12)
            .toList()
    }

    companion object {
        private const val FIVE_MINUTES_MS = 5 * 60 * 1000L

        fun formatStudyFocusTime(seconds: Int): String {
            val hrs = seconds / 3600
            val mins = (seconds % 3600) / 60
            val secs = seconds % 60
            return if (hrs > 0) {
                String.format(Locale.US, "%dh %02dm today", hrs, mins)
            } else {
                String.format(Locale.US, "%02dm %02ds today", mins, secs)
            }
        }
    }
}
