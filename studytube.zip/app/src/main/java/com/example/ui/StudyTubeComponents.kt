package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.ApiErrorState
import com.example.data.CORE_SUBJECT_CHIPS
import com.example.data.CachedChannelIdentity
import com.example.data.StudyVideo
import com.example.data.WHITELISTED_CHANNELS
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.StudyBorder
import com.example.ui.theme.StudyEmerald
import com.example.ui.theme.StudyObsidian
import com.example.ui.theme.StudySkyBlue
import com.example.ui.theme.StudySurface
import com.example.ui.theme.StudySurfaceVariant
import com.example.ui.theme.StudyTextMuted
import com.example.ui.theme.StudyTextPrimary
import com.example.ui.theme.StudyTextSecondary

@Composable
fun StudyTubeTopBar(
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    studiedSecondsToday: Int,
    isTimerRunning: Boolean,
    onToggleTimer: () -> Unit,
    isSyncing: Boolean,
    onRefreshClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onHtmlDialogClick: () -> Unit,
    onBrandClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = StudyObsidian.copy(alpha = 0.96f),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Top Row: Brand + Study Focus Timer + Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(9.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onBrandClick() }
                        .padding(vertical = 2.dp, horizontal = 2.dp)
                        .testTag("brand_logo_button")
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF0284C7), StudySkyBlue)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "StudyTube Logo",
                            tint = StudyObsidian,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "StudyTube",
                                style = MaterialTheme.typography.titleLarge,
                                color = StudyTextPrimary
                            )
                            Surface(
                                color = StudySkyBlue.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(5.dp)
                            ) {
                                Text(
                                    text = "JEE • NEET",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StudySkyBlue,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "Whitelist Only • Zero Shorts",
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                            color = StudyTextSecondary
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    StudyFocusTimerBadge(
                        studiedSecondsToday = studiedSecondsToday,
                        isRunning = isTimerRunning,
                        onClick = onToggleTimer
                    )

                    IconButton(
                        onClick = onHtmlDialogClick,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("single_file_html_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Code,
                            contentDescription = "Single-File index.html Web App",
                            tint = StudySkyBlue
                        )
                    }

                    IconButton(
                        onClick = onRefreshClick,
                        enabled = !isSyncing,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("refresh_feed_button")
                    ) {
                        if (isSyncing) {
                            CircularProgressIndicator(
                                strokeWidth = 2.dp,
                                color = StudySkyBlue,
                                modifier = Modifier.size(18.dp)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh Whitelisted Feed",
                                tint = StudyTextPrimary
                            )
                        }
                    }

                    IconButton(
                        onClick = onSettingsClick,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("open_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "YouTube API Key Settings",
                            tint = StudyTextPrimary
                        )
                    }
                }
            }

            // Search Bar (strictly searches within whitelisted channels' fetched videos)
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                singleLine = true,
                placeholder = {
                    Text(
                        text = "Search Physics, Chemistry, Maths, Biology in whitelisted channels…",
                        style = MaterialTheme.typography.bodyMedium,
                        color = StudyTextMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = StudyTextSecondary
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(
                            onClick = { onSearchQueryChange("") },
                            modifier = Modifier.testTag("clear_search_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Clear Search",
                                tint = StudyTextSecondary
                            )
                        }
                    }
                },
                shape = RoundedCornerShape(999.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = StudySurfaceVariant,
                    unfocusedContainerColor = StudySurface,
                    focusedBorderColor = StudySkyBlue,
                    unfocusedBorderColor = StudyBorder,
                    focusedTextColor = StudyTextPrimary,
                    unfocusedTextColor = StudyTextPrimary,
                    cursorColor = StudySkyBlue
                ),
                textStyle = MaterialTheme.typography.bodyMedium,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("whitelist_search_input")
            )
        }
    }
}

@Composable
fun StudyFocusTimerBadge(
    studiedSecondsToday: Int,
    isRunning: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor = if (isRunning) StudyEmerald.copy(alpha = 0.16f) else StudySurfaceVariant
    val borderColor = if (isRunning) StudyEmerald.copy(alpha = 0.45f) else StudyBorder
    val contentColor = if (isRunning) Color(0xFF34D399) else StudyTextSecondary

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(999.dp),
        border = BorderStroke(1.dp, borderColor),
        modifier = modifier
            .clip(RoundedCornerShape(999.dp))
            .clickable { onClick() }
            .testTag("study_focus_timer_badge")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(if (isRunning) StudyEmerald else StudyTextMuted)
            )
            Text(
                text = StudyTubeViewModel.formatStudyFocusTime(studiedSecondsToday),
                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                color = contentColor,
                fontWeight = FontWeight.Bold
            )
            Icon(
                imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (isRunning) "Pause Study Timer" else "Resume Study Timer",
                tint = contentColor,
                modifier = Modifier.size(13.dp)
            )
        }
    }
}

@Composable
fun WhitelistFilterChipsRow(
    activeChip: String,
    onSelectChip: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 4.dp)
            .testTag("filter_chips_row"),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Core Subject & Exam chips: All, Physics, Chemistry, Maths, Biology, JEE, NEET
        CORE_SUBJECT_CHIPS.forEach { chipName ->
            val isSelected = activeChip == chipName
            FilterChip(
                selected = isSelected,
                onClick = { onSelectChip(chipName) },
                label = {
                    Text(
                        text = chipName,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                },
                shape = RoundedCornerShape(999.dp),
                colors = FilterChipDefaults.filterChipColors(
                    containerColor = StudySurface,
                    labelColor = StudyTextSecondary,
                    selectedContainerColor = StudySkyBlue,
                    selectedLabelColor = StudyObsidian
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = isSelected,
                    borderColor = StudyBorder,
                    selectedBorderColor = StudySkyBlue
                ),
                modifier = Modifier.testTag("chip_${chipName.lowercase()}")
            )
        }

        VerticalDivider(
            modifier = Modifier
                .height(22.dp)
                .padding(horizontal = 2.dp),
            color = StudyBorder
        )

        // One chip per whitelisted channel
        WHITELISTED_CHANNELS.forEach { channel ->
            val chipKey = "channel:${channel.key}"
            val isSelected = activeChip == chipKey
            FilterChip(
                selected = isSelected,
                onClick = { onSelectChip(chipKey) },
                label = {
                    Text(
                        text = channel.shortName,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                },
                shape = RoundedCornerShape(999.dp),
                colors = FilterChipDefaults.filterChipColors(
                    containerColor = StudySurface,
                    labelColor = StudyTextSecondary,
                    selectedContainerColor = StudySkyBlue,
                    selectedLabelColor = StudyObsidian
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = isSelected,
                    borderColor = StudyBorder,
                    selectedBorderColor = StudySkyBlue
                ),
                modifier = Modifier.testTag("chip_channel_${channel.key}")
            )
        }
    }
}

@Composable
fun StudyVideoCard(
    video: StudyVideo,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = StudySurface),
        border = BorderStroke(1.dp, StudyBorder),
        modifier = modifier
            .fillMaxWidth()
            .testTag("video_card_${video.id}")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .background(Color(0xFF070A10))
            ) {
                AsyncImage(
                    model = video.thumbnailUrl,
                    contentDescription = video.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Top-left primary subject badge
                video.tags.firstOrNull()?.let { primaryTag ->
                    Surface(
                        color = StudyObsidian.copy(alpha = 0.86f),
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, StudySkyBlue.copy(alpha = 0.35f)),
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                    ) {
                        Text(
                            text = primaryTag,
                            style = MaterialTheme.typography.labelSmall,
                            color = StudySkyBlue,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                        )
                    }
                }

                // Bottom-right monospace duration badge
                Surface(
                    color = StudyObsidian.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.14f)),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                ) {
                    Text(
                        text = video.durationFormatted,
                        style = MaterialTheme.typography.labelMedium,
                        color = StudyTextPrimary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 13.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = video.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = StudyTextPrimary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Text(
                        text = video.channelTitle,
                        style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.5.sp),
                        color = Color(0xFFCBD5E1),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Whitelisted Educator",
                        tint = StudySkyBlue,
                        modifier = Modifier.size(13.dp)
                    )
                }

                Text(
                    text = "${video.viewsFormatted} • ${video.relativeTimeText}",
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                    color = StudyTextMuted
                )
            }
        }
    }
}

@Composable
fun ApiErrorBanner(
    errorState: ApiErrorState,
    onOpenSettings: () -> Unit,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.55f)
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.6f)),
        modifier = modifier
            .fillMaxWidth()
            .testTag("api_error_banner")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "API Warning",
                    tint = Color(0xFFFDA4AF)
                )
                Text(
                    text = errorState.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = Color(0xFFFDA4AF),
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = errorState.message,
                style = MaterialTheme.typography.bodyMedium,
                color = StudyTextPrimary
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onOpenSettings,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StudySkyBlue,
                        contentColor = StudyObsidian
                    ),
                    modifier = Modifier.testTag("error_update_key_button")
                ) {
                    Text("Update API Key", fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onRetry,
                    border = BorderStroke(1.dp, StudyBorder),
                    modifier = Modifier.testTag("error_retry_button")
                ) {
                    Text("Retry Sync", color = StudyTextPrimary)
                }
            }
        }
    }
}

@Composable
fun ApiKeySettingsDialog(
    currentApiKey: String,
    cachedChannels: Map<String, CachedChannelIdentity>,
    onDismiss: () -> Unit,
    onSaveApiKey: (String) -> Unit,
    onClearCache: () -> Unit
) {
    var apiKeyText by remember(currentApiKey) { mutableStateOf(currentApiKey) }
    var showRawKey by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = StudySurface),
            border = BorderStroke(1.dp, StudyBorder),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("api_key_settings_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Key,
                        contentDescription = null,
                        tint = StudySkyBlue
                    )
                    Text(
                        text = "YouTube Data API v3 Setup",
                        style = MaterialTheme.typography.titleLarge,
                        color = StudyTextPrimary
                    )
                }

                Text(
                    text = "Paste your official YouTube Data API v3 key below. StudyTube saves it locally on your device, resolves each whitelisted channel ID once to conserve quota, and filters out all Shorts (<=60s or #shorts) and live streams.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = StudyTextSecondary
                )

                OutlinedTextField(
                    value = apiKeyText,
                    onValueChange = { apiKeyText = it },
                    label = { Text("YouTube Data API v3 Key") },
                    placeholder = { Text("AIzaSy...") },
                    singleLine = true,
                    visualTransformation = if (showRawKey) {
                        VisualTransformation.None
                    } else {
                        PasswordVisualTransformation()
                    },
                    trailingIcon = {
                        Text(
                            text = if (showRawKey) "HIDE" else "SHOW",
                            style = MaterialTheme.typography.labelSmall,
                            color = StudySkyBlue,
                            modifier = Modifier
                                .clickable { showRawKey = !showRawKey }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = StudyObsidian,
                        unfocusedContainerColor = StudyObsidian,
                        focusedBorderColor = StudySkyBlue,
                        unfocusedBorderColor = StudyBorder,
                        focusedTextColor = StudyTextPrimary,
                        unfocusedTextColor = StudyTextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("api_key_input_field")
                )

                // Whitelisted Channel ID Cache status
                Surface(
                    color = StudyObsidian,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, StudyBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = StudyEmerald,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = "Whitelisted Channels (${WHITELISTED_CHANNELS.size})",
                                style = MaterialTheme.typography.labelLarge,
                                color = StudyTextPrimary
                            )
                        }
                        WHITELISTED_CHANNELS.forEach { ch ->
                            val cachedId = cachedChannels[ch.key]?.channelId
                            Text(
                                text = "• ${ch.name} — ${cachedId ?: "Resolves on sync"}",
                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.5.sp),
                                color = if (cachedId != null) StudySkyBlue else StudyTextSecondary
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onClearCache,
                        border = BorderStroke(1.dp, StudyBorder),
                        modifier = Modifier.testTag("reset_cache_button")
                    ) {
                        Text("Reset Cache", color = StudyTextSecondary)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (currentApiKey.isNotBlank()) {
                            OutlinedButton(
                                onClick = onDismiss,
                                border = BorderStroke(1.dp, StudyBorder)
                            ) {
                                Text("Cancel", color = StudyTextPrimary)
                            }
                        }
                        Button(
                            onClick = { onSaveApiKey(apiKeyText) },
                            enabled = apiKeyText.trim().isNotEmpty(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = StudySkyBlue,
                                contentColor = StudyObsidian
                            ),
                            modifier = Modifier.testTag("save_api_key_button")
                        ) {
                            Text("Save & Sync", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SingleFileHtmlExportDialog(
    htmlCode: String,
    isWebViewModeActive: Boolean,
    onToggleWebViewMode: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = StudySurface),
            border = BorderStroke(1.dp, StudyBorder),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("single_file_html_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Single-File index.html Web App",
                    style = MaterialTheme.typography.titleLarge,
                    color = StudyTextPrimary
                )

                Text(
                    text = "StudyTube includes the complete, self-contained single-file HTML + CSS + vanilla JS web app (`assets/index.html`). You can copy the entire file to run in any mobile/desktop browser, or launch it right here.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = StudyTextSecondary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("StudyTube index.html", htmlCode))
                            Toast.makeText(context, "Complete index.html copied to clipboard!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = StudySkyBlue,
                            contentColor = StudyObsidian
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("copy_index_html_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Copy index.html", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = {
                            onToggleWebViewMode(!isWebViewModeActive)
                            onDismiss()
                        },
                        border = BorderStroke(1.dp, StudySkyBlue),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("toggle_webview_mode_button")
                    ) {
                        Text(
                            text = if (isWebViewModeActive) "Use Native UI" else "Run index.html",
                            color = StudySkyBlue,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                HorizontalDivider(color = StudyBorder)

                Surface(
                    color = StudyObsidian,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, StudyBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 140.dp, max = 220.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(10.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Text(
                            text = htmlCode.take(2500) + "\n... [Full single-file code copied via button above]",
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                            color = StudyTextSecondary
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        border = BorderStroke(1.dp, StudyBorder)
                    ) {
                        Text("Close", color = StudyTextPrimary)
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyFeedHeroBanner(
    hasApiKey: Boolean,
    onConfigureApiKey: () -> Unit,
    onResetFilters: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = StudySurface),
        border = BorderStroke(1.dp, StudyBorder),
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .testTag("empty_feed_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Shield,
                contentDescription = null,
                tint = StudySkyBlue,
                modifier = Modifier.size(40.dp)
            )
            Text(
                text = if (!hasApiKey) {
                    "Connect Your YouTube Data API v3 Key"
                } else {
                    "No Matching Whitelisted Lectures"
                },
                style = MaterialTheme.typography.titleLarge,
                color = StudyTextPrimary
            )
            Text(
                text = if (!hasApiKey) {
                    "StudyTube fetches full-length JEE & NEET lectures exclusively from Physics Wallah, Unacademy, Vedantu, ALLEN, and Motion. Shorts (<=60s), live streams, and external recommendations are permanently blocked."
                } else {
                    "No lectures matched your active subject chip or search filter. Try resetting filters or refreshing the whitelisted feed."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = StudyTextSecondary
            )

            Spacer(modifier = Modifier.height(4.dp))

            if (!hasApiKey) {
                Button(
                    onClick = onConfigureApiKey,
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = StudySkyBlue,
                        contentColor = StudyObsidian
                    ),
                    modifier = Modifier.testTag("empty_configure_key_button")
                ) {
                    Text("Paste YouTube API Key", fontWeight = FontWeight.Bold)
                }
            } else {
                OutlinedButton(
                    onClick = onResetFilters,
                    border = BorderStroke(1.dp, StudySkyBlue),
                    modifier = Modifier.testTag("empty_reset_filters_button")
                ) {
                    Text("Show All Whitelisted Lectures", color = StudySkyBlue)
                }
            }
        }
    }
}
