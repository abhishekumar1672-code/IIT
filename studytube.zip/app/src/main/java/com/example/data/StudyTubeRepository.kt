package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

class StudyTubeRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val appContext: Context = context.applicationContext

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val channelListType = Types.newParameterizedType(
        List::class.java,
        CachedChannelIdentity::class.java
    )
    private val channelMapAdapter = moshi.adapter<List<CachedChannelIdentity>>(channelListType)

    private val videoListType = Types.newParameterizedType(
        List::class.java,
        StudyVideo::class.java
    )
    private val videoListAdapter = moshi.adapter<List<StudyVideo>>(videoListType)

    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val apiService: YouTubeApiService = Retrofit.Builder()
        .baseUrl("https://www.googleapis.com/")
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(YouTubeApiService::class.java)

    fun getEffectiveApiKey(): String {
        return prefs.getString(KEY_API_KEY, "")?.trim().orEmpty()
    }

    fun hasUserSavedApiKey(): Boolean {
        return getEffectiveApiKey().isNotEmpty()
    }

    fun saveApiKey(apiKey: String) {
        prefs.edit().putString(KEY_API_KEY, apiKey.trim()).apply()
    }

    fun getCachedChannelMap(): MutableMap<String, CachedChannelIdentity> {
        val raw = prefs.getString(KEY_CHANNEL_CACHE, null) ?: return mutableMapOf()
        return runCatching {
            val list = channelMapAdapter.fromJson(raw).orEmpty()
            list.associateBy { it.channelKey }.toMutableMap()
        }.getOrDefault(mutableMapOf())
    }

    private fun saveCachedChannelMap(map: Map<String, CachedChannelIdentity>) {
        runCatching {
            val json = channelMapAdapter.toJson(map.values.toList())
            prefs.edit().putString(KEY_CHANNEL_CACHE, json).apply()
        }
    }

    fun getCachedVideos(): List<StudyVideo> {
        val raw = prefs.getString(KEY_VIDEOS_CACHE, null) ?: return emptyList()
        return runCatching {
            videoListAdapter.fromJson(raw).orEmpty()
                .filter { isStrictValidLecture(it.durationSeconds, it.title) }
                .map { it.copy(relativeTimeText = formatRelativeDaysAgo(it.publishedEpochMs)) }
        }.getOrDefault(emptyList())
    }

    private fun saveCachedVideos(videos: List<StudyVideo>) {
        runCatching {
            val json = videoListAdapter.toJson(videos)
            prefs.edit()
                .putString(KEY_VIDEOS_CACHE, json)
                .putLong(KEY_LAST_SYNC_MS, System.currentTimeMillis())
                .apply()
        }
    }

    fun getLastSyncEpochMs(): Long {
        return prefs.getLong(KEY_LAST_SYNC_MS, 0L)
    }

    fun clearFeedAndChannelCache() {
        prefs.edit()
            .remove(KEY_CHANNEL_CACHE)
            .remove(KEY_VIDEOS_CACHE)
            .remove(KEY_LAST_SYNC_MS)
            .apply()
    }

    fun getStudiedSecondsToday(): Int {
        val today = getTodayDateKey()
        val savedDate = prefs.getString(KEY_STUDY_DATE, "")
        return if (savedDate == today) {
            prefs.getInt(KEY_STUDY_SECONDS, 0)
        } else {
            prefs.edit()
                .putString(KEY_STUDY_DATE, today)
                .putInt(KEY_STUDY_SECONDS, 0)
                .apply()
            0
        }
    }

    fun incrementAndSaveStudySeconds(deltaSeconds: Int = 1): Int {
        val today = getTodayDateKey()
        val savedDate = prefs.getString(KEY_STUDY_DATE, "")
        val base = if (savedDate == today) prefs.getInt(KEY_STUDY_SECONDS, 0) else 0
        val updated = base + deltaSeconds
        prefs.edit()
            .putString(KEY_STUDY_DATE, today)
            .putInt(KEY_STUDY_SECONDS, updated)
            .apply()
        return updated
    }

    fun readSingleFileHtmlAsset(): String {
        return runCatching {
            appContext.assets.open("index.html").bufferedReader().use { it.readText() }
        }.getOrDefault("<!-- Unable to load index.html asset -->")
    }

    private fun getTodayDateKey(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return sdf.format(Date())
    }

    /**
     * Resolves a whitelisted channel's ID & uploads playlist ID once using channels.list
     * (or a single search fallback), then caches it in SharedPreferences / localStorage.
     */
    private suspend fun resolveWhitelistedChannel(
        config: WhitelistedChannelConfig,
        apiKey: String,
        cacheMap: MutableMap<String, CachedChannelIdentity>
    ): CachedChannelIdentity? {
        cacheMap[config.key]?.let { existing ->
            if (existing.channelId.isNotBlank() && existing.uploadsPlaylistId.isNotBlank()) {
                return existing
            }
        }

        // 1. Try channels.list by handle (costs 1 quota unit)
        if (config.handle.isNotBlank()) {
            val response = apiService.getChannelByHandle(
                forHandle = config.handle,
                apiKey = apiKey
            )
            checkFatalApiError(response)?.let { throw ApiException(it) }
            val item = response.body()?.items?.firstOrNull()
            if (item?.id != null) {
                val uploadsId = item.contentDetails?.relatedPlaylists?.uploads
                    ?: ("UU" + item.id.removePrefix("UC"))
                val resolved = CachedChannelIdentity(
                    channelKey = config.key,
                    channelId = item.id,
                    uploadsPlaylistId = uploadsId,
                    resolvedTitle = item.snippet?.title ?: config.name
                )
                synchronized(cacheMap) {
                    cacheMap[config.key] = resolved
                }
                return resolved
            }
        }

        // 2. Try known defaultChannelId via channels.list (costs 1 quota unit)
        if (config.defaultChannelId.startsWith("UC")) {
            val response = apiService.getChannelById(
                channelId = config.defaultChannelId,
                apiKey = apiKey
            )
            checkFatalApiError(response)?.let { throw ApiException(it) }
            val item = response.body()?.items?.firstOrNull()
            if (item?.id != null) {
                val uploadsId = item.contentDetails?.relatedPlaylists?.uploads
                    ?: ("UU" + item.id.removePrefix("UC"))
                val resolved = CachedChannelIdentity(
                    channelKey = config.key,
                    channelId = item.id,
                    uploadsPlaylistId = uploadsId,
                    resolvedTitle = item.snippet?.title ?: config.name
                )
                synchronized(cacheMap) {
                    cacheMap[config.key] = resolved
                }
                return resolved
            }
        }

        // 3. Fallback single search for channel (cached permanently after first run)
        val searchRes = apiService.searchChannelOnce(
            query = config.searchQuery,
            apiKey = apiKey
        )
        checkFatalApiError(searchRes)?.let { throw ApiException(it) }
        val found = searchRes.body()?.items?.firstOrNull()
        val channelId = found?.snippet?.channelId ?: found?.id?.channelId
        if (!channelId.isNullOrBlank() && channelId.startsWith("UC")) {
            val resolved = CachedChannelIdentity(
                channelKey = config.key,
                channelId = channelId,
                uploadsPlaylistId = "UU" + channelId.removePrefix("UC"),
                resolvedTitle = found?.snippet?.title ?: config.name
            )
            synchronized(cacheMap) {
                cacheMap[config.key] = resolved
            }
            return resolved
        }

        return null
    }

    suspend fun syncWhitelistedFeed(): Result<List<StudyVideo>> = withContext(Dispatchers.IO) {
        val apiKey = getEffectiveApiKey()
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                ApiException(
                    ApiErrorState(
                        type = ApiErrorType.INVALID_KEY,
                        title = "YouTube API Key Required",
                        message = "Please paste your YouTube Data API v3 key in Settings to load JEE & NEET lectures."
                    )
                )
            )
        }

        try {
            val channelCache = getCachedChannelMap()
            val resolvedChannels = mutableListOf<Pair<WhitelistedChannelConfig, CachedChannelIdentity>>()

            for (ch in WHITELISTED_CHANNELS) {
                val resolved = resolveWhitelistedChannel(ch, apiKey, channelCache)
                if (resolved != null) {
                    resolvedChannels.add(ch to resolved)
                }
            }
            saveCachedChannelMap(channelCache)

            if (resolvedChannels.isEmpty()) {
                return@withContext Result.failure(
                    ApiException(
                        ApiErrorState(
                            type = ApiErrorType.NETWORK_OR_OTHER,
                            title = "Could Not Resolve Channels",
                            message = "Unable to resolve whitelisted channel IDs. Verify your YouTube Data API v3 key and network connection."
                        )
                    )
                )
            }

            // Fetch latest videos from each channel's "uploads" playlist via playlistItems.list
            val videoIdToChannelPair = linkedMapOf<String, Pair<WhitelistedChannelConfig, CachedChannelIdentity>>()

            val playlistResults = coroutineScope {
                resolvedChannels.map { (config, identity) ->
                    async {
                        val response = apiService.getPlaylistItems(
                            playlistId = identity.uploadsPlaylistId,
                            maxResults = 12,
                            apiKey = apiKey
                        )
                        checkFatalApiError(response)?.let { throw ApiException(it) }
                        val items = response.body()?.items.orEmpty()
                        items.mapNotNull { item ->
                            val vid = item.contentDetails?.videoId ?: item.snippet?.resourceId?.videoId
                            if (!vid.isNullOrBlank()) vid to (config to identity) else null
                        }
                    }
                }.awaitAll()
            }

            for (channelBatch in playlistResults) {
                for ((videoId, pair) in channelBatch) {
                    if (!videoIdToChannelPair.containsKey(videoId)) {
                        videoIdToChannelPair[videoId] = pair
                    }
                }
            }

            val allVideoIds = videoIdToChannelPair.keys.toList()
            if (allVideoIds.isEmpty()) {
                return@withContext Result.failure(
                    ApiException(
                        ApiErrorState(
                            type = ApiErrorType.NETWORK_OR_OTHER,
                            title = "No Videos Found",
                            message = "No recent uploads were returned from the whitelisted channels."
                        )
                    )
                )
            }

            // Batch call videos.list (up to 50 video IDs per request) to inspect durations and filter Shorts/live
            val detailedItems = mutableListOf<YtVideoItem>()
            for (chunk in allVideoIds.chunked(50)) {
                val vResponse = apiService.getVideosDetails(
                    videoIdsCsv = chunk.joinToString(","),
                    apiKey = apiKey
                )
                checkFatalApiError(vResponse)?.let { throw ApiException(it) }
                detailedItems.addAll(vResponse.body()?.items.orEmpty())
            }

            // STRICT FILTERING:
            // 1. Remove every video <= 60 seconds
            // 2. Remove anything with "#shorts" or "#short" in title or description
            // 3. Hide live and upcoming streams
            val filteredLectures = mutableListOf<StudyVideo>()
            for (item in detailedItems) {
                val videoId = item.id ?: continue
                val snippet = item.snippet ?: continue
                val title = snippet.title?.trim().orEmpty()
                val description = snippet.description.orEmpty()
                val durationIso = item.contentDetails?.duration.orEmpty()
                val durationSeconds = parseIsoDurationSeconds(durationIso)

                if (!isStrictValidLecture(durationSeconds, title, description)) continue

                val broadcast = (snippet.liveBroadcastContent ?: "none").lowercase(Locale.US)
                if (broadcast == "live" || broadcast == "upcoming") continue
                if (item.liveStreamingDetails != null && item.liveStreamingDetails.actualEndTime.isNullOrBlank()) {
                    continue
                }

                val pair = videoIdToChannelPair[videoId] ?: continue
                val (config, identity) = pair

                val publishedIso = snippet.publishedAt.orEmpty()
                val publishedEpoch = parseIsoDateEpoch(publishedIso)
                val views = item.statistics?.viewCount?.toLongOrNull() ?: 0L
                val thumb = snippet.thumbnails?.maxres?.url
                    ?: snippet.thumbnails?.high?.url
                    ?: snippet.thumbnails?.medium?.url
                    ?: "https://i.ytimg.com/vi/$videoId/hqdefault.jpg"

                val tags = classifyLectureTags(title, description, config)

                filteredLectures.add(
                    StudyVideo(
                        id = videoId,
                        title = title,
                        channelKey = config.key,
                        channelId = snippet.channelId ?: identity.channelId,
                        channelTitle = config.shortName,
                        fullChannelName = config.name,
                        thumbnailUrl = thumb,
                        publishedAt = publishedIso,
                        publishedEpochMs = publishedEpoch,
                        durationSeconds = durationSeconds,
                        durationFormatted = formatDuration(durationSeconds),
                        viewCount = views,
                        viewsFormatted = formatViews(views),
                        relativeTimeText = formatRelativeDaysAgo(publishedEpoch),
                        tags = tags
                    )
                )
            }

            val sorted = filteredLectures.sortedByDescending { it.publishedEpochMs }
            saveCachedVideos(sorted)
            Result.success(sorted)
        } catch (e: ApiException) {
            Result.failure(e)
        } catch (e: Exception) {
            Result.failure(
                ApiException(
                    ApiErrorState(
                        type = ApiErrorType.NETWORK_OR_OTHER,
                        title = "Connection Issue",
                        message = e.localizedMessage
                            ?: "Unable to reach YouTube Data API v3. Showing cached lectures."
                    )
                )
            )
        }
    }

    private fun <T> checkFatalApiError(response: Response<T>): ApiErrorState? {
        if (response.isSuccessful) return null
        val code = response.code()
        val errBody = runCatching { response.errorBody()?.string().orEmpty() }.getOrDefault("")
        val lower = errBody.lowercase(Locale.US)

        return when {
            code == 400 || lower.contains("keyinvalid") || lower.contains("api key not valid") -> {
                ApiErrorState(
                    type = ApiErrorType.INVALID_KEY,
                    title = "Invalid YouTube API Key",
                    message = "Your YouTube Data API v3 key was rejected. Please verify the key in Settings and ensure YouTube Data API v3 is enabled."
                )
            }
            code == 403 && (lower.contains("quotaexceeded") || lower.contains("quota") || lower.contains("dailylimitexceeded")) -> {
                ApiErrorState(
                    type = ApiErrorType.QUOTA_EXCEEDED,
                    title = "YouTube API Quota Exceeded",
                    message = "Your daily YouTube Data API v3 quota has been reached. You can continue watching your cached JEE & NEET lectures or paste another key."
                )
            }
            code == 403 -> {
                ApiErrorState(
                    type = ApiErrorType.INVALID_KEY,
                    title = "API Access Restricted (403)",
                    message = "Access denied by YouTube Data API v3. Ensure YouTube Data API v3 is enabled for this key."
                )
            }
            else -> {
                ApiErrorState(
                    type = ApiErrorType.NETWORK_OR_OTHER,
                    title = "YouTube API Error ($code)",
                    message = "Could not complete request (HTTP $code). Showing cached lectures if available."
                )
            }
        }
    }

    companion object {
        private const val PREFS_NAME = "studytube_local_cache"
        private const val KEY_API_KEY = "yt_api_key"
        private const val KEY_CHANNEL_CACHE = "whitelisted_channels_cache_v1"
        private const val KEY_VIDEOS_CACHE = "whitelisted_videos_cache_v1"
        private const val KEY_LAST_SYNC_MS = "last_sync_epoch_ms_v1"
        private const val KEY_STUDY_DATE = "study_focus_date_v1"
        private const val KEY_STUDY_SECONDS = "study_focus_seconds_v1"

        private val DURATION_REGEX = Regex("""PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?""")
        private val SHORTS_TAG_REGEX = Regex("""#shorts?\b""", RegexOption.IGNORE_CASE)

        fun parseIsoDurationSeconds(isoDuration: String): Int {
            if (isoDuration.isBlank()) return 0
            val match = DURATION_REGEX.matchEntire(isoDuration.trim()) ?: return 0
            val hours = match.groupValues[1].toIntOrNull() ?: 0
            val minutes = match.groupValues[2].toIntOrNull() ?: 0
            val seconds = match.groupValues[3].toIntOrNull() ?: 0
            return hours * 3600 + minutes * 60 + seconds
        }

        fun isStrictValidLecture(
            durationSeconds: Int,
            title: String,
            description: String = ""
        ): Boolean {
            if (durationSeconds <= 60) return false
            if (SHORTS_TAG_REGEX.containsMatchIn(title)) return false
            if (description.isNotEmpty() && SHORTS_TAG_REGEX.containsMatchIn(description)) return false
            return true
        }

        fun formatDuration(totalSeconds: Int): String {
            val hrs = totalSeconds / 3600
            val mins = (totalSeconds % 3600) / 60
            val secs = totalSeconds % 60
            return if (hrs > 0) {
                String.format(Locale.US, "%d:%02d:%02d", hrs, mins, secs)
            } else {
                String.format(Locale.US, "%d:%02d", mins, secs)
            }
        }

        fun formatViews(views: Long): String {
            return when {
                views >= 1_000_000L -> String.format(Locale.US, "%.1fM views", views / 1_000_000.0)
                    .replace(".0M", "M")
                views >= 1_000L -> String.format(Locale.US, "%.1fK views", views / 1_000.0)
                    .replace(".0K", "K")
                else -> "$views views"
            }
        }

        fun parseIsoDateEpoch(isoDate: String): Long {
            if (isoDate.isBlank()) return System.currentTimeMillis()
            val formats = listOf(
                "yyyy-MM-dd'T'HH:mm:ss'Z'",
                "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
            )
            for (pattern in formats) {
                runCatching {
                    val sdf = SimpleDateFormat(pattern, Locale.US).apply {
                        timeZone = TimeZone.getTimeZone("UTC")
                    }
                    sdf.parse(isoDate)?.time?.let { return it }
                }
            }
            return System.currentTimeMillis()
        }

        fun formatRelativeDaysAgo(publishedEpochMs: Long): String {
            val diffSeconds = ((System.currentTimeMillis() - publishedEpochMs) / 1000L).coerceAtLeast(1L)
            val days = diffSeconds / 86400L
            return when {
                days == 0L -> {
                    val hours = (diffSeconds / 3600L).coerceAtLeast(1L)
                    if (hours == 1L) "1 hour ago" else "$hours hours ago"
                }
                days == 1L -> "1 day ago"
                days < 30L -> "$days days ago"
                days < 365L -> {
                    val months = (days / 30L).coerceAtLeast(1L)
                    if (months == 1L) "1 month ago" else "$months months ago"
                }
                else -> {
                    val years = (days / 365L).coerceAtLeast(1L)
                    if (years == 1L) "1 year ago" else "$years years ago"
                }
            }
        }

        fun classifyLectureTags(
            title: String,
            description: String,
            config: WhitelistedChannelConfig
        ): List<String> {
            val text = "$title $description".lowercase(Locale.US)
            val tags = linkedSetOf<String>()

            if (Regex("""physics|electrostatics|mechanics|optics|thermodynamics|kinematics|magnetism|current|modern physics|gravitation|waves|shm|rotational|semiconductor|capacitor""").containsMatchIn(text)) {
                tags.add("Physics")
            }
            if (Regex("""chemistry|organic|inorganic|physical chem|mole|periodic|equilibrium|thermochemistry|electrochemistry|coordination|hydrocarbon|aldehyde|amine|polymer|atomic structure|chemical bonding""").containsMatchIn(text)) {
                tags.add("Chemistry")
            }
            if (Regex("""math|maths|mathematics|calculus|algebra|trigonometry|coordinate|matrix|matrices|determinant|vector|3d|probability|integration|differentiation|conic|complex number""").containsMatchIn(text)) {
                tags.add("Maths")
            }
            if (Regex("""biology|botany|zoology|genetics|ecology|human physiology|plant physiology|cell|reproduction|biotechnology|evolution|anatomy|morphology|biomolecules""").containsMatchIn(text)) {
                tags.add("Biology")
            }

            if (Regex("""jee|iit|mains|advanced|bitsat""").containsMatchIn(text) || config.examCategory == "JEE") {
                tags.add("JEE")
            }
            if (Regex("""neet|aiims|medical|ncert biology""").containsMatchIn(text) || config.examCategory == "NEET") {
                tags.add("NEET")
            }

            if (tags.isEmpty()) {
                tags.addAll(config.defaultSubjects)
            } else if ("JEE" !in tags && "NEET" !in tags) {
                if (config.examCategory == "BOTH") {
                    tags.add("JEE")
                    tags.add("NEET")
                } else {
                    tags.add(config.examCategory)
                }
            }

            return tags.toList()
        }
    }
}

class ApiException(val errorState: ApiErrorState) : Exception(errorState.message)
