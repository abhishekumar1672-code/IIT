package com.example.data

import com.squareup.moshi.JsonClass
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface YouTubeApiService {

    @GET("youtube/v3/channels")
    suspend fun getChannelByHandle(
        @Query("part") part: String = "id,snippet,contentDetails",
        @Query("forHandle") forHandle: String,
        @Query("key") apiKey: String
    ): Response<YtChannelListResponse>

    @GET("youtube/v3/channels")
    suspend fun getChannelById(
        @Query("part") part: String = "id,snippet,contentDetails",
        @Query("id") channelId: String,
        @Query("key") apiKey: String
    ): Response<YtChannelListResponse>

    @GET("youtube/v3/search")
    suspend fun searchChannelOnce(
        @Query("part") part: String = "snippet",
        @Query("type") type: String = "channel",
        @Query("maxResults") maxResults: Int = 1,
        @Query("q") query: String,
        @Query("key") apiKey: String
    ): Response<YtSearchListResponse>

    @GET("youtube/v3/playlistItems")
    suspend fun getPlaylistItems(
        @Query("part") part: String = "snippet,contentDetails",
        @Query("playlistId") playlistId: String,
        @Query("maxResults") maxResults: Int = 12,
        @Query("key") apiKey: String
    ): Response<YtPlaylistItemsResponse>

    @GET("youtube/v3/videos")
    suspend fun getVideosDetails(
        @Query("part") part: String = "snippet,contentDetails,statistics,liveStreamingDetails",
        @Query("id") videoIdsCsv: String,
        @Query("key") apiKey: String
    ): Response<YtVideoListResponse>
}

@JsonClass(generateAdapter = true)
data class YtChannelListResponse(
    val items: List<YtChannelItem>? = emptyList()
)

@JsonClass(generateAdapter = true)
data class YtChannelItem(
    val id: String?,
    val snippet: YtChannelSnippet?,
    val contentDetails: YtChannelContentDetails?
)

@JsonClass(generateAdapter = true)
data class YtChannelSnippet(
    val title: String?
)

@JsonClass(generateAdapter = true)
data class YtChannelContentDetails(
    val relatedPlaylists: YtRelatedPlaylists?
)

@JsonClass(generateAdapter = true)
data class YtRelatedPlaylists(
    val uploads: String?
)

@JsonClass(generateAdapter = true)
data class YtSearchListResponse(
    val items: List<YtSearchItem>? = emptyList()
)

@JsonClass(generateAdapter = true)
data class YtSearchItem(
    val id: YtSearchId?,
    val snippet: YtSearchSnippet?
)

@JsonClass(generateAdapter = true)
data class YtSearchId(
    val channelId: String?
)

@JsonClass(generateAdapter = true)
data class YtSearchSnippet(
    val channelId: String?,
    val title: String?
)

@JsonClass(generateAdapter = true)
data class YtPlaylistItemsResponse(
    val items: List<YtPlaylistItem>? = emptyList()
)

@JsonClass(generateAdapter = true)
data class YtPlaylistItem(
    val snippet: YtPlaylistItemSnippet?,
    val contentDetails: YtPlaylistItemContentDetails?
)

@JsonClass(generateAdapter = true)
data class YtPlaylistItemSnippet(
    val title: String?,
    val resourceId: YtResourceId?
)

@JsonClass(generateAdapter = true)
data class YtResourceId(
    val videoId: String?
)

@JsonClass(generateAdapter = true)
data class YtPlaylistItemContentDetails(
    val videoId: String?
)

@JsonClass(generateAdapter = true)
data class YtVideoListResponse(
    val items: List<YtVideoItem>? = emptyList()
)

@JsonClass(generateAdapter = true)
data class YtVideoItem(
    val id: String?,
    val snippet: YtVideoSnippet?,
    val contentDetails: YtVideoContentDetails?,
    val statistics: YtVideoStatistics?,
    val liveStreamingDetails: YtLiveStreamingDetails?
)

@JsonClass(generateAdapter = true)
data class YtVideoSnippet(
    val publishedAt: String?,
    val channelId: String?,
    val channelTitle: String?,
    val title: String?,
    val description: String?,
    val thumbnails: YtThumbnails?,
    val liveBroadcastContent: String?
)

@JsonClass(generateAdapter = true)
data class YtThumbnails(
    val maxres: YtThumbnailUrl?,
    val high: YtThumbnailUrl?,
    val medium: YtThumbnailUrl?,
    val default: YtThumbnailUrl?
)

@JsonClass(generateAdapter = true)
data class YtThumbnailUrl(
    val url: String?
)

@JsonClass(generateAdapter = true)
data class YtVideoContentDetails(
    val duration: String?
)

@JsonClass(generateAdapter = true)
data class YtVideoStatistics(
    val viewCount: String?
)

@JsonClass(generateAdapter = true)
data class YtLiveStreamingDetails(
    val actualStartTime: String?,
    val actualEndTime: String?,
    val scheduledStartTime: String?
)
