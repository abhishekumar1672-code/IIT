package com.example.data

import com.squareup.moshi.JsonClass

/**
 * Easy-to-edit array of whitelisted JEE & NEET educational channels at the top of the codebase.
 * Only videos from these channels are ever fetched, searched, or recommended.
 */
data class WhitelistedChannelConfig(
    val key: String,
    val name: String,
    val shortName: String,
    val handle: String,
    val searchQuery: String,
    val defaultChannelId: String = "",
    val examCategory: String, // "JEE", "NEET", or "BOTH"
    val defaultSubjects: List<String>
)

val WHITELISTED_CHANNELS: List<WhitelistedChannelConfig> = listOf(
    WhitelistedChannelConfig(
        key = "pw_alakh",
        name = "Physics Wallah - Alakh Pandey",
        shortName = "PW Alakh Pandey",
        handle = "@PhysicsWallah",
        searchQuery = "Physics Wallah Alakh Pandey",
        defaultChannelId = "UCiGyWN6DEbnj2alu7iapuKQ",
        examCategory = "BOTH",
        defaultSubjects = listOf("Physics", "Chemistry", "JEE", "NEET")
    ),
    WhitelistedChannelConfig(
        key = "pw_jee",
        name = "JEE Wallah (PW JEE)",
        shortName = "PW JEE",
        handle = "@PW-JEEWallah",
        searchQuery = "JEE Wallah Physics Wallah",
        defaultChannelId = "UCVJU_IChPMOe8RWkdVQjtfQ",
        examCategory = "JEE",
        defaultSubjects = listOf("Physics", "Chemistry", "Maths", "JEE")
    ),
    WhitelistedChannelConfig(
        key = "competition_wallah",
        name = "Competition Wallah (PW NEET)",
        shortName = "Competition Wallah",
        handle = "@PW-NEETWallah",
        searchQuery = "Competition Wallah NEET",
        defaultChannelId = "UCD16eo98AXl-9T61Xd711kQ",
        examCategory = "NEET",
        defaultSubjects = listOf("Physics", "Chemistry", "Biology", "NEET")
    ),
    WhitelistedChannelConfig(
        key = "pw_hindi",
        name = "PW Hindi Medium",
        shortName = "PW Hindi Medium",
        handle = "@PWHindiMedium",
        searchQuery = "PW Hindi Medium JEE NEET",
        defaultChannelId = "",
        examCategory = "BOTH",
        defaultSubjects = listOf("Physics", "Chemistry", "Maths", "Biology", "JEE", "NEET")
    ),
    WhitelistedChannelConfig(
        key = "ncert_wallah",
        name = "NCERT Wallah (PW)",
        shortName = "NCERT Wallah",
        handle = "@NCERTWallahPW",
        searchQuery = "NCERT Wallah Physics Wallah",
        defaultChannelId = "",
        examCategory = "BOTH",
        defaultSubjects = listOf("Physics", "Chemistry", "Maths", "Biology", "JEE", "NEET")
    ),
    WhitelistedChannelConfig(
        key = "unacademy_jee",
        name = "Unacademy JEE",
        shortName = "Unacademy JEE",
        handle = "@UnacademyJEE",
        searchQuery = "Unacademy JEE",
        defaultChannelId = "UCZNNx4KYlutJfGWbDMpnVlQ",
        examCategory = "JEE",
        defaultSubjects = listOf("Physics", "Chemistry", "Maths", "JEE")
    ),
    WhitelistedChannelConfig(
        key = "unacademy_neet",
        name = "Unacademy NEET",
        shortName = "Unacademy NEET",
        handle = "@UnacademyNEET",
        searchQuery = "Unacademy NEET",
        defaultChannelId = "UCdQwYksctqqiRwqp3PiJMWA",
        examCategory = "NEET",
        defaultSubjects = listOf("Physics", "Chemistry", "Biology", "NEET")
    ),
    WhitelistedChannelConfig(
        key = "vedantu_jee",
        name = "Vedantu JEE",
        shortName = "Vedantu JEE",
        handle = "@JEEVedantu",
        searchQuery = "Vedantu JEE",
        defaultChannelId = "UC91RZv71f8p0VV2gaFI07pg",
        examCategory = "JEE",
        defaultSubjects = listOf("Physics", "Chemistry", "Maths", "JEE")
    ),
    WhitelistedChannelConfig(
        key = "vedantu_neet",
        name = "Vedantu NEET Made Ejee",
        shortName = "Vedantu NEET",
        handle = "@NEETVedantu",
        searchQuery = "Vedantu NEET Made Ejee",
        defaultChannelId = "UCqaq3Cwa7m_E3ff2TvGr9dw",
        examCategory = "NEET",
        defaultSubjects = listOf("Physics", "Chemistry", "Biology", "NEET")
    ),
    WhitelistedChannelConfig(
        key = "allen",
        name = "ALLEN Career Institute",
        shortName = "ALLEN",
        handle = "@ALLENCareerInstituteofficial",
        searchQuery = "ALLEN Career Institute JEE NEET",
        defaultChannelId = "UCLLM4a26397592c3mD7d9Jw",
        examCategory = "BOTH",
        defaultSubjects = listOf("Physics", "Chemistry", "Maths", "Biology", "JEE", "NEET")
    ),
    WhitelistedChannelConfig(
        key = "motion_jee",
        name = "Motion JEE",
        shortName = "Motion JEE",
        handle = "@Motion_Online",
        searchQuery = "Motion Education NV Sir JEE",
        defaultChannelId = "UC8cd3013C234a5D8b5B3b8w",
        examCategory = "JEE",
        defaultSubjects = listOf("Physics", "Chemistry", "Maths", "JEE")
    )
)

val CORE_SUBJECT_CHIPS: List<String> = listOf(
    "All", "Physics", "Chemistry", "Maths", "Biology", "JEE", "NEET"
)

@JsonClass(generateAdapter = true)
data class CachedChannelIdentity(
    val channelKey: String,
    val channelId: String,
    val uploadsPlaylistId: String,
    val resolvedTitle: String
)

@JsonClass(generateAdapter = true)
data class StudyVideo(
    val id: String,
    val title: String,
    val channelKey: String,
    val channelId: String,
    val channelTitle: String,
    val fullChannelName: String,
    val thumbnailUrl: String,
    val publishedAt: String,
    val publishedEpochMs: Long,
    val durationSeconds: Int,
    val durationFormatted: String,
    val viewCount: Long,
    val viewsFormatted: String,
    val relativeTimeText: String,
    val tags: List<String>
)

enum class ApiErrorType {
    INVALID_KEY,
    QUOTA_EXCEEDED,
    NETWORK_OR_OTHER
}

data class ApiErrorState(
    val type: ApiErrorType,
    val title: String,
    val message: String
)
