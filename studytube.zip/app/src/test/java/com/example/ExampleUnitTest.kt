package com.example

import com.example.data.StudyTubeRepository
import com.example.data.WHITELISTED_CHANNELS
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun parseIsoDurationSeconds_parsesHoursMinutesAndSecondsCorrectly() {
        assertEquals(45, StudyTubeRepository.parseIsoDurationSeconds("PT45S"))
        assertEquals(60, StudyTubeRepository.parseIsoDurationSeconds("PT1M"))
        assertEquals(61, StudyTubeRepository.parseIsoDurationSeconds("PT1M1S"))
        assertEquals(3725, StudyTubeRepository.parseIsoDurationSeconds("PT1H2M5S"))
    }

    @Test
    fun isStrictValidLecture_blocksShortsAnd60SecondsOrLess() {
        assertFalse(StudyTubeRepository.isStrictValidLecture(60, "Quick Electrostatics Formula"))
        assertFalse(StudyTubeRepository.isStrictValidLecture(30, "JEE Tip"))
        assertFalse(StudyTubeRepository.isStrictValidLecture(900, "Rotational Motion Trick #shorts"))
        assertFalse(StudyTubeRepository.isStrictValidLecture(1200, "NEET Biology #Shorts Revision"))
        assertTrue(StudyTubeRepository.isStrictValidLecture(1800, "Complete Electrostatics One Shot JEE Main & Advanced"))
    }

    @Test
    fun whitelistedChannels_containsRequiredJeeAndNeetChannels() {
        val names = WHITELISTED_CHANNELS.map { it.name }.joinToString(" | ")
        assertTrue(names.contains("Physics Wallah"))
        assertTrue(names.contains("Competition Wallah"))
        assertTrue(names.contains("Unacademy JEE"))
        assertTrue(names.contains("Vedantu JEE"))
        assertTrue(names.contains("ALLEN"))
        assertTrue(names.contains("Motion"))
    }
}
