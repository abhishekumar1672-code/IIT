# StudyTube — Distraction-Free JEE & NEET Video Learning Platform

StudyTube is a minimalist, high-focus educational video client powered by the official YouTube Data API v3. It restricts discovery exclusively to whitelisted JEE and NEET coaching channels, strictly filters out YouTube Shorts, live streams, and external algorithmic recommendations, and integrates a daily Study Focus timer to keep aspirants on track.

## User Review & Critical Decisions

> [!IMPORTANT]
> Because this project runs in an Android workspace while the prompt also requests a self-contained single-file `index.html` implementation, **both experiences are delivered together**:
> 1. **Native Jetpack Compose Android App**: Full native Material 3 Dark UI with Jetpack Compose, Retrofit + Moshi networking, local caching, an embedded YouTube IFrame Player view, and a companion "Export / View Single-File `index.html`" sheet.
> 2. **Complete Single-File `index.html` Web App (`assets/index.html`)**: A 100% self-contained single-file HTML + CSS + vanilla JS web app bundled in Android assets that can be launched interactively inside the app or copied/exported directly.

- **Confirmed Decision 1 (Architecture & Delivery)**: Deliver a native Jetpack Compose Android experience alongside the complete, self-contained single-file `index.html` web app so it works seamlessly in the Android emulator and as a standalone single-file web application.
- **Confirmed Decision 2 (API Key Configuration)**: Show an in-app Settings modal/screen on first launch where users can paste and save their YouTube Data API v3 key locally, while also supporting `YOUTUBE_API_KEY` via AI Studio's Secrets panel (`BuildConfig.YOUTUBE_API_KEY`) as an automatic fallback.
- **Confirmed Decision 3 (Study Focus Timer)**: Track daily study time automatically when a lecture is open/playing, with a manual pause/resume toggle and automatic midnight reset persisted across sessions.

---

## 1. Overview & Core Concept

- **What It Does**: Aggregates the latest full-length lectures from India's top JEE and NEET educators (Physics Wallah, Unacademy, Vedantu, ALLEN, Motion) using the YouTube Data API v3, strips away Shorts (`<= 60s` or `#shorts`), live streams, comments, and algorithmic distractions, and plays videos strictly through the official YouTube embedded iframe player.
- **Target Audience / Persona**: JEE (Joint Entrance Examination) and NEET (National Eligibility cum Entrance Test) aspirants who rely on YouTube lectures for Physics, Chemistry, Mathematics, and Biology preparation but want zero exposure to Shorts or rabbit-hole recommendations.
- **Key Value**: Saves API quota via intelligent two-tier local caching (channel IDs + video feed), refreshes automatically every 5 minutes and on app foregrounding, and reinforces daily discipline with a real-time Study Focus timer in the top bar.

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **First-Launch API Key Setup**: On initial launch (if no API key is saved or injected via `BuildConfig`), a clean Settings dialog prompts the student to paste their YouTube Data API v3 key, validates it against the API, and caches it locally.
  2. **Subject & Channel Filtering**: Students browse a responsive dark-themed video grid and filter instantly using the horizontal chip bar (`All`, `Physics`, `Chemistry`, `Maths`, `Biology`, `JEE`, `NEET`, plus individual chips for every whitelisted channel).
  3. **In-Feed Whitelist Search**: Typing in the top search bar filters and searches strictly within the fetched videos from the whitelisted channels.
  4. **Distraction-Free Watch Page**: Tapping any video opens the Watch screen featuring the official YouTube embedded iframe player (`rel=0`, `modestbranding=1`, `playsinline=1`), lecture metadata, a "Study Timer Active" indicator, and a curated list of related lectures strictly from the whitelisted channels below.
  5. **Auto-Refresh & Foreground Sync**: The feed opens instantaneously from local cache and silently refreshes in the background every 5 minutes or whenever the app returns to the foreground (`ON_RESUME` / `visibilitychange`).

- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Deep Obsidian Study Dark — utilitarian, high-contrast academic dark mode engineered for late-night study sessions without eye strain.
  - *Color Palette & Mood*:
    - `--background`: `#0B0F17` (Deep Obsidian)
    - `--surface`: `#131B2E` (Elevated Slate Card)
    - `--surface-variant`: `#1E293B` (Chip & Input Surface)
    - `--primary`: `#38BDF8` (Focused Sky Blue for active chips & primary actions)
    - `--accent`: `#10B981` (Emerald Focus Green for the active Study Timer badge)
    - `--danger`: `#F43F5E` (Crimson for API quota/key alerts)
    - `--text-primary`: `#F8FAFC`, `--text-secondary`: `#94A3B8`
  - *Typography & Hierarchy*: Bundled Google Fonts (`Plus Jakarta Sans` for crisp lecture titles and headers, `Inter` for metadata, and `JetBrains Mono` for video duration badges and the Study Focus timer).
  - *Component Styling & Layout*:
    - Sticky top app bar with StudyTube brand mark, live monospace Study Focus pill (`01h 24m today`), search input, mode switcher (Native / Single-File Web view), and Settings gear.
    - Single-row scrollable filter rail with distinct visual separation between exam/subject chips and channel chips.
    - 16:9 thumbnail cards with bottom-right monospace duration badges (`24:15`), 2-line clamped titles, channel badge, formatted view counts (`142K views`), and relative timestamps (`3 days ago`).

- **Interactive Feedback & Motion**:
  - Shimmer/skeleton placeholders during initial quota-friendly channel resolution.
  - Friendly, actionable error cards for invalid API keys (`400/403`), quota exhaustion (`403 quotaExceeded`), or network offline states—with a one-tap button to update the key or continue browsing cached lectures.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Easy-to-Edit Channel Whitelist Array & Permanent Channel ID Caching**
  - *Chosen Approach*: Define `WHITELISTED_CHANNELS` at the very top of the codebase containing all requested channels:
    - Physics Wallah – Alakh Pandey (`@PhysicsWallah`)
    - PW JEE / JEE Wallah (`@PW-JEEWallah`)
    - PW NEET / Competition Wallah (`@PW-NEETWallah`)
    - PW Hindi Medium (`@PWHindiMedium`)
    - Unacademy JEE (`@UnacademyJEE`)
    - Unacademy NEET (`@UnacademyNEET`)
    - Vedantu JEE (`@JEEVedantu`)
    - Vedantu NEET (`@NEETVedantu`)
    - ALLEN Career Institute (`@ALLENCareerInstituteofficial`)
    - Motion JEE (`@Motion_Online`)
  - *Why*: Resolving each channel once via `channels.list` (using `forHandle` or `id`) or a single fallback `search.list` (`type=channel`) and permanently storing the resolved Channel ID + Uploads Playlist ID (`UU...` derived from `UC...` or `contentDetails.relatedPlaylists.uploads`) in local storage saves hundreds of API quota units on subsequent launches.

- **Decision 2: Strict Anti-Shorts & Anti-Stream Filtering Pipeline**
  - *Chosen Approach*: Fetch recent items per channel using `playlistItems.list` (1 quota unit per call), batch video IDs (up to 50 per request) into `videos.list?part=contentDetails,statistics,snippet,liveStreamingDetails` (1 quota unit per batch), parse ISO-8601 durations (`PT#H#M#S`), and discard any video where:
    1. Duration is `<= 60` seconds.
    2. Title or description contains `#shorts` or `#short` (case-insensitive).
    3. `snippet.liveBroadcastContent` is `"live"` or `"upcoming"`, or `liveStreamingDetails` indicates an unended/upcoming stream.
  - *Why*: `playlistItems.list` + batched `videos.list` uses ~98% less quota than `search.list` (which costs 100 units per call) while guaranteeing complete duration and live-status metadata to eliminate Shorts completely.

- **Decision 3: Dual Native + Single-File `index.html` Architecture**
  - *Chosen Approach*: Provide both a native Jetpack Compose UI and the complete single-file `index.html` in `app/src/main/assets/index.html` (accessible via an in-app toggle and copy/export dialog).
  - *Why*: Satisfies the Android Studio build environment guidelines while giving the user the exact single-file HTML+CSS+JS artifact requested in the prompt.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```
┌───────────────────────────────────────────────────────────────────────────┐
│                         StudyTube Android & Web App                       │
├─────────────────────────────────────┬─────────────────────────────────────┤
│   Native Jetpack Compose Layer      │   Single-File Web App (index.html)  │
│  ┌───────────────────────────────┐  │  ┌───────────────────────────────┐  │
│  │ TopBar + StudyFocusTimerPill  │  │  │ Header + Search + Timer Badge │  │
│  ├───────────────────────────────┤  │  ├───────────────────────────────┤  │
│  │ Subject & Channel Chip Rail   │  │  │ Filter Chips (Subj + Channel) │  │
│  ├───────────────────────────────┤  │  ├───────────────────────────────┤  │
│  │ VideoFeedGrid / WatchScreen   │  │  │ Video Grid / IFrame Watch View│  │
│  ├───────────────────────────────┤  │  ├───────────────────────────────┤  │
│  │ API Key & HTML Export Dialogs │  │  │ Settings Modal & Quota Alerts │  │
│  └───────────────┬───────────────┘  │  └───────────────┬───────────────┘  │
└──────────────────┼──────────────────┴──────────────────┼──────────────────┘
                   ▼                                     ▼
┌───────────────────────────────────────────────────────────────────────────┐
│                 StudyTube Repository & Caching Engine                     │
│  1. Whitelist Resolver: channels.list(forHandle/id) -> Cache Channel IDs  │
│  2. Feed Fetcher: playlistItems.list(uploads) -> Batch videos.list        │
│  3. Strict Filter: duration > 60s && !#shorts && broadcast == "none"      │
│  4. Classifier: Auto-tag Physics / Chemistry / Maths / Biology / JEE/NEET │
│  5. Local Cache: SharedPreferences / localStorage + 5-min & Resume Sync   │
└─────────────────────────────────────┬─────────────────────────────────────┘
                                      ▼
┌───────────────────────────────────────────────────────────────────────────┐
│        Official YouTube Data API v3 & YouTube Embedded IFrame Player      │
└───────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State

- **`WhitelistedChannel`**: `name`, `handle`, `fallbackQuery`, `examCategory` (`JEE`, `NEET`, `BOTH`), `resolvedChannelId`, `uploadsPlaylistId`.
- **`StudyVideo`**: `id`, `title`, `channelId`, `channelTitle`, `thumbnailUrl`, `publishedAt`, `durationSeconds`, `formattedDuration`, `viewCount`, `formattedViews`, `relativeTime`, `subjectTags` (`Physics`, `Chemistry`, `Maths`, `Biology`, `JEE`, `NEET`).
- **`StudyTimerState`**: `dateKey` (`YYYY-MM-DD`), `elapsedSecondsToday`, `isRunning`, `isAutoTrackingPlayer`.
- **`FeedUiState`**: `Loading`, `Success(videos, lastUpdated, isRefreshing)`, `MissingApiKey`, `ApiError(type: INVALID_KEY | QUOTA_EXCEEDED | NETWORK, message, cachedVideos)`.

### Interactive Component & State Mapping

- **API Key Settings Handler**: Validates non-empty input, saves to local storage (`SharedPreferences` / `localStorage`), clears previous error states, and triggers immediate channel resolution and feed sync.
- **Chip & Search Filter Handler**: Combines active chip (`All`, subject tag, exam tag, or specific `channelId`) with the search query string to filter cached videos instantaneously in memory without burning API quota.
- **Watch Page & Embedded Player Handler**: Opens selected `StudyVideo` in the official `https://www.youtube.com/embed/{videoId}?autoplay=1&rel=0&modestbranding=1&playsinline=1` iframe player, computes related videos from the cached whitelist pool (prioritizing same subject/channel), and activates the Study Focus timer.
- **Auto-Refresh & Lifecycle Observer**: Registers a 5-minute coroutine ticker / `setInterval` and a `LifecycleEventObserver` (`ON_RESUME` / `document.visibilitychange`) that refreshes the feed if the cache is older than 5 minutes.
